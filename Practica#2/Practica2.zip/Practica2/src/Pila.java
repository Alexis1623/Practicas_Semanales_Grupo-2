
import java.util.HashSet;
import java.util.Set;


public class Pila {
        private Platos cima;
        private int largo;
        private int SumaCucharas;
        private int SumaCuchillos;
        private int SumaTenedores;
        public Pila() {
        this.cima = null; //Cima apunta a null, pila vacia
        this.largo = 0;//Inicia en cero porque la pila esta vacia
    }
    
    public boolean Vacia(){
        return cima == null; //Retorna un verdadero si esta vacia es decir si la cima apunta a null
    } 
    
    public int dimension(){ 
        return this.largo; 
    }
    
     public void push(int codigo, String material, int  tenedor, int cuchara, int cuchillo ){
        Platos newPlato = new Platos();//Crear un objeto de la clase platos
        newPlato.setCodigo(codigo);
        newPlato.setMaterial(material);
        newPlato.setTenedores(tenedor);
        newPlato.setCucharas(cuchara);
        newPlato.setCuchillos(cuchillo);
        SumaCucharas += cuchara; // Se van sumando los cubiertos que se le agreguen
        SumaTenedores += tenedor;
        SumaCuchillos += cuchillo;
        if (this.Vacia()){
            this.cima = newPlato;
        } //Si la pila esta vacía crea un objeto
        else{
            newPlato.setSiguiente(this.cima);                
            this.cima = newPlato;
            
        }//Si la pila no esta vacia crea un nuevo plato que pasará a ser la cima
        this.largo++;
    }
      public void listar(){
        Platos aux = cima; //Creamos una variabñe auxiliar que nos irá recorriendo la lista
        while(aux != null){
            System.out.println( "Codigo: " + aux.getCodigo() +" | Traste: "+ aux.getMaterial() + " | Cubiertos: Tenedores: " + SumaTenedores + 
                    " Cucharas: " + SumaCucharas + " Cuchillos: " + SumaCuchillos);
            System.out.println("--------------------------------------------");
            aux = aux.getSiguiente();
        }
    }

    void push(int i, String vaso, int i0, String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
