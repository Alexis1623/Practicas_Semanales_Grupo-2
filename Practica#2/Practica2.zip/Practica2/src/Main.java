
public class Main {

    
    public static void main(String[] args) {
        Pila newPila = new Pila();
        //Crear objetos (Platos)
         newPila.push(1, "Vaso" , 1,1,1);
         newPila.push(2, "Plato Metal" , 1,1,0);
       newPila.push(3, "Plato Plastico" , 0,0,0);
        newPila.listar();//Mostrar los objetos
    }
}
