
public class Platos {
    
    //Atributos
    private String material;
    private int codigo;
    private int Tenedores;
    private int Cucharas;
    private int Cuchillos;
    
    private Platos siguiente;

    public Platos() {
        this.material = "";
        this.codigo = 0;
        this.siguiente = null;
    }

    public String getMaterial() {
        return material;
    }

    public int getCodigo() {
        return codigo;
    }

    public Platos getSiguiente() {
        return siguiente;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setSiguiente(Platos siguiente) {
        this.siguiente = siguiente;
    }

    public void setTenedores(int Tenedores) {
        this.Tenedores = Tenedores;
    }

    public void setCucharas(int Cucharas) {
        this.Cucharas = Cucharas;
    }

    public void setCuchillos(int Cuchillos) {
        this.Cuchillos = Cuchillos;
    }

    public int getTenedores() {
        return Tenedores;
    }

    public int getCucharas() {
        return Cucharas;
    }

    public int getCuchillos() {
        return Cuchillos;
    }
    
    
    
    
}
