
package ejercicio04;

public class Ejercicio {
    
    
    public int Factorial(int parametro){
    if(parametro >0){
    int valor_calculado = parametro *Factorial(parametro - 1);
    return valor_calculado;
    }
        return 1;
    
    }


public int calcExponencial(int num, int exp){
if(exp==0){
return 1;
}else{
return num* calcExponencial(num,exp-1);

}
}
    }

