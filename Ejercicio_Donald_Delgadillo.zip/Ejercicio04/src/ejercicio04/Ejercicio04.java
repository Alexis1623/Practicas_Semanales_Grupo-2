
package ejercicio04;

public class Ejercicio04 {

    public static void main(String[] args) {
        Ejercicio e = new Ejercicio();
       int resultado =  e.Factorial(3);
        System.out.println(resultado);
        
        int result = e.calcExponencial(3,3);
        System.out.println(result);
    }
    
}
